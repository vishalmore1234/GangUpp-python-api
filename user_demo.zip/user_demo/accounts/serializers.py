from django.contrib.auth.models import User, Group
from rest_framework import serializers
from .models import Players
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login  
from rest_framework import exceptions
from django.contrib.auth.models import User, Group
from .models import Quiz_up


class PlayersSer(serializers.ModelSerializer):
    class Meta:
        model = Players
        fields = ['Player_name',
                'day_score', 
                'season_score', 
                'attended',
                'accuracy',
                'total_days_of_season',
                'number_of_days_participated',
                'consecutive_streak',
                'date']

class PlayersleadSer(serializers.ModelSerializer):
    class Meta:
        model = Players
        fields = ['Player_name',
                'day_score', 
                'season_score',]



class QuizupSerializer(serializers.ModelSerializer):

    class Meta:
        model = Quiz_up
        fields = "__all__"


        




